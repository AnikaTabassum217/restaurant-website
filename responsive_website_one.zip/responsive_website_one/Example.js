// const plus = document.querySelector(".plus"),
// minus = document.querySelector(".minus"),
// digit = document.querySelector(".digit");

// let a=1;

// plus.addEventListener("click",()=>{
//     a++;
//     a=(a<10)? "0" +a:a;
//     digit.innerText=a;
//     console.log(a);
// });


// minus.addEventListener("click",()=>{
//    if(a>1){
//     a++;
//     a=(a<10)? "0" +a:a;
//     digit.innerText=a;
//     console.log(a);
//    }
// });
// function incrementValue() {
//     var countElement = document.getElementById("count");
//     var count = parseInt(countElement.textContent);
//     count++;
//     countElement.textContent = count;
//   }



// BURGER

function incrementBurger() {
    var countElement = document.getElementById("burgerCount");
    var burgerCount = parseInt(countElement.textContent);
    burgerCount++;
    countElement.textContent = burgerCount;
}
function decrementBurger() {
    var countElement = document.getElementById("burgerCount");
    var burgerCount = parseInt(countElement.textContent);
    burgerCount--;
    countElement.textContent = burgerCount;
}

// SAWARMA

function incrementSawarma() {
    var countElement = document.getElementById("sawarmaCount");
    var sawarmaCount = parseInt(countElement.textContent);
    sawarmaCount++;
    countElement.textContent = sawarmaCount;
}
function decrementSawarma() {
    var countElement = document.getElementById("sawarmaCount");
    var sawarmaCount = parseInt(countElement.textContent);
    sawarmaCount--;
    countElement.textContent = sawarmaCount;
}


// SANDWICH

function incrementSandwich() {
    var countElement = document.getElementById("sandwichCount");
    var sandwichCount = parseInt(countElement.textContent);
    sandwichCount++;
    countElement.textContent = sandwichCount;
}
function decrementSandwich() {
    var countElement = document.getElementById("sandwichCount");
    var sandwichCount = parseInt(countElement.textContent);
    sandwichCount--;
    countElement.textContent = sandwichCount;
}

//CROISSANT

function incrementCroissant() {
    var countElement = document.getElementById("croissantCount");
    var croissantCount = parseInt(countElement.textContent);
    croissantCount++;
    countElement.textContent = croissantCount;
}
function decrementCroissant() {
    var countElement = document.getElementById("croissantCount");
    var croissantCount = parseInt(countElement.textContent);
    croissantCount--;
    countElement.textContent = croissantCount;
}


